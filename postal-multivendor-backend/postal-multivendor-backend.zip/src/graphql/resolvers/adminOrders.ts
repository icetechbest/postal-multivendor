import { Types } from 'mongoose';
import { Order } from '../../models/Order';
import { Restaurant } from '../../models/Restaurant';
import { User } from '../../models/User';
import { AuthContext, requireRole } from '../../middleware/auth';
import { pubsub } from '../../services/pubsub';
import { AuthorizationError, NotFoundError, ValidationError } from '../../utils/errors';
import { ensureOrderAccess, idOf, publishOrderUpdate } from './appHelpers';
import { assertObjectId, cleanId, dateRange, escapeRegex, pageParams, requirePlatformReader } from './adminHelpers';

const STATUSES = ['PENDING', 'ACCEPTED', 'ASSIGNED', 'PICKED', 'DELIVERED', 'COMPLETED', 'CANCELLED'];

const populate = (query: any) =>
  query.populate('restaurant').populate('user').populate('rider').populate({ path: 'items.food', model: 'Food' });

/** Base filter limiting what the caller may see: admins/staff all, vendors their stores, riders their orders. */
const scopeFilter = async (context: AuthContext, restaurantId?: string | null): Promise<Record<string, any>> => {
  const filter: Record<string, any> = {};
  const role = context.user!.role;
  if (role === 'RIDER') filter.rider = new Types.ObjectId(context.user!.userId);
  else if (role === 'VENDOR') {
    const ids = (await Restaurant.find({ owner: context.user!.userId }).select('_id')).map((r) => idOf(r._id));
    if (restaurantId && !ids.includes(restaurantId)) throw new AuthorizationError();
    filter.restaurant = restaurantId ? new Types.ObjectId(restaurantId) : { $in: ids.map((id) => new Types.ObjectId(id)) };
  } else if (role === 'ADMIN' || role === 'STAFF') {
    if (restaurantId) filter.restaurant = new Types.ObjectId(assertObjectId(restaurantId, 'restaurant'));
  } else throw new AuthorizationError();
  return filter;
};

const searchFilter = (search?: string | null) => {
  if (!search?.trim()) return null;
  const rx = { $regex: escapeRegex(search.trim()), $options: 'i' };
  return { $or: [{ orderId: rx }, { 'deliveryAddress.deliveryAddress': rx }] };
};

const paged = async (filter: Record<string, any>, page: number, limit: number) => {
  const p = pageParams(page, limit, 10);
  const [orders, totalCount] = await Promise.all([
    populate(Order.find(filter).sort({ createdAt: -1 }).skip(p.skip).limit(p.limit)),
    Order.countDocuments(filter),
  ]);
  const totalPages = Math.max(1, Math.ceil(totalCount / p.limit));
  return { orders, totalCount, currentPage: p.page, totalPages, nextPage: p.page < totalPages ? p.page + 1 : null, prevPage: p.page > 1 ? p.page - 1 : null };
};

const and = (...parts: Array<Record<string, any> | null | undefined>) => {
  const list = parts.filter((p): p is Record<string, any> => Boolean(p) && Object.keys(p as object).length > 0);
  return list.length ? { $and: list } : {};
};

export const adminOrderResolvers = {
  Query: {
    getActiveOrders: async (_parent: unknown, args: any, context: AuthContext) => {
      requireRole(context, ['ADMIN', 'STAFF', 'VENDOR', 'RIDER']);
      const scope = await scopeFilter(context, cleanId(args.restaurantId));
      const statuses: string[] = (args.actions?.length ? args.actions : args.status ? [args.status] : []).map((s: string) => s.toUpperCase()).filter((s: string) => STATUSES.includes(s));
      const status = statuses.length ? { orderStatus: { $in: statuses } } : { orderStatus: { $nin: ['COMPLETED', 'CANCELLED'] } };
      return paged(and(scope, status, searchFilter(args.search)), args.page, args.rowsPerPage ?? args.limit);
    },
    ordersByRestId: async (_parent: unknown, args: any, context: AuthContext) => {
      requireRole(context, ['ADMIN', 'STAFF', 'VENDOR']);
      const scope = await scopeFilter(context, assertObjectId(args.restaurant, 'restaurant'));
      const status = args.status ? { orderStatus: args.status.toUpperCase() } : null;
      const p = pageParams(args.page, args.rows ?? args.limit, 10);
      return populate(Order.find(and(scope, status, searchFilter(args.search))).sort({ createdAt: -1 }).skip(p.skip).limit(p.limit));
    },
    ordersByRestIdWithoutPagination: async (_parent: unknown, args: { restaurant: string; search?: string }, context: AuthContext) => {
      requireRole(context, ['ADMIN', 'STAFF', 'VENDOR']);
      const scope = await scopeFilter(context, assertObjectId(args.restaurant, 'restaurant'));
      return populate(Order.find(and(scope, searchFilter(args.search))).sort({ createdAt: -1 }).limit(5000));
    },
    ordersByUser: async (_parent: unknown, args: { userId: string; page?: number; limit?: number }, context: AuthContext) => {
      requireRole(context, ['ADMIN', 'STAFF', 'USER']);
      const userId = assertObjectId(args.userId, 'user');
      if (context.user!.role === 'USER' && context.user!.userId !== userId) throw new AuthorizationError();
      return paged({ user: new Types.ObjectId(userId) }, args.page ?? 1, args.limit ?? 10);
    },
    allOrders: async (_parent: unknown, args: { page?: number }, context: AuthContext) => {
      requirePlatformReader(context);
      const p = pageParams(args.page, 50, 50);
      return populate(Order.find().sort({ createdAt: -1 }).skip(p.skip).limit(p.limit));
    },
    allOrdersPaginated: async (_parent: unknown, args: any, context: AuthContext) => {
      requirePlatformReader(context);
      const range = dateRange(args.dateKeyword, args.starting_date, args.ending_date);
      const statuses = (args.orderStatus || []).map((s: string) => s.toUpperCase()).filter((s: string) => STATUSES.includes(s));
      return paged(
        and(range ? { createdAt: range } : null, statuses.length ? { orderStatus: { $in: statuses } } : null, searchFilter(args.search)),
        args.page,
        args.rows
      );
    },
    allOrdersWithoutPagination: async (_parent: unknown, args: any, context: AuthContext) => {
      requirePlatformReader(context);
      const range = dateRange(args.dateKeyword, args.starting_date, args.ending_date);
      return populate(Order.find(range ? { createdAt: range } : {}).sort({ createdAt: -1 }).limit(10000));
    },
  },

  Mutation: {
    updateStatus: async (_parent: unknown, { id, orderStatus }: { id: string; orderStatus: string }, context: AuthContext) => {
      requireRole(context, ['ADMIN', 'STAFF', 'VENDOR', 'RIDER']);
      const status = orderStatus.toUpperCase();
      if (!STATUSES.includes(status)) throw new ValidationError('Invalid order status');
      const order = await Order.findById(assertObjectId(id, 'order'));
      if (!order) throw new NotFoundError('Order');
      if (context.user!.role === 'STAFF') {
        // Staff operate on behalf of the platform.
      } else await ensureOrderAccess(order, context, true);
      const now = new Date();
      order.orderStatus = status as typeof order.orderStatus;
      if (status === 'ACCEPTED') order.acceptedAt = now;
      if (status === 'PICKED') {
        order.pickedAt = now;
        order.isPickedUp = true;
      }
      if (status === 'DELIVERED') {
        order.deliveredAt = now;
        order.completionTime = now;
      }
      if (status === 'COMPLETED') {
        order.completedAt = now;
        order.completionTime = now;
      }
      if (status === 'CANCELLED') order.cancelledAt = now;
      if (['DELIVERED', 'COMPLETED'].includes(status) && order.paymentMethod === 'COD') {
        order.paymentStatus = 'PAID';
        order.paidAmount = order.total;
      }
      await order.save();
      return publishOrderUpdate(order._id, 'updateStatus');
    },
    assignRider: async (_parent: unknown, args: { id?: string; orderId?: string; riderId: string }, context: AuthContext) => {
      requireRole(context, ['ADMIN', 'STAFF', 'VENDOR']);
      const orderId = cleanId(args.orderId) || cleanId(args.id);
      if (!orderId) throw new ValidationError('Order id is required');
      const order = await Order.findById(assertObjectId(orderId, 'order'));
      if (!order) throw new NotFoundError('Order');
      if (context.user!.role !== 'STAFF') await ensureOrderAccess(order, context, true);
      const rider = await User.findOne({ _id: assertObjectId(args.riderId, 'rider'), role: 'RIDER', isActive: true });
      if (!rider) throw new ValidationError('Invalid rider');
      order.rider = rider._id as any;
      order.orderStatus = 'ASSIGNED';
      order.riderAssignedAt = new Date();
      order.assignedAt = order.riderAssignedAt;
      await order.save();
      return publishOrderUpdate(order._id, 'assignRider');
    },
  },

  Subscription: {
    subscribePlaceOrder: {
      subscribe: async (_parent: unknown, { restaurant }: { restaurant: string }, context: AuthContext) => {
        requireRole(context, ['ADMIN', 'STAFF', 'VENDOR']);
        const store = await Restaurant.findById(assertObjectId(restaurant, 'restaurant'));
        if (!store) throw new NotFoundError('Restaurant');
        if (context.user!.role === 'VENDOR' && idOf(store.owner) !== context.user!.userId) throw new AuthorizationError();
        return pubsub.asyncIterableIterator([`ORDER_PLACED_${restaurant}`]);
      },
      resolve: (payload: any) => {
        const order = payload.subscribePlaceOrder;
        return { userId: idOf(order.user), origin: 'new', order };
      },
    },
    subscriptionDispatcher: {
      subscribe: (_parent: unknown, _args: unknown, context: AuthContext) => {
        requireRole(context, ['ADMIN', 'STAFF']);
        return pubsub.asyncIterableIterator(['DISPATCHER_ORDERS']);
      },
    },
    riderUpdated: {
      subscribe: (_parent: unknown, _args: unknown, context: AuthContext) => {
        requireRole(context, ['ADMIN', 'STAFF']);
        return pubsub.asyncIterableIterator(['RIDER_UPDATED']);
      },
    },
  },
};

export const adminOrderFields = {
  Order: {
    zone: async (parent: any) => {
      const restaurant = await Restaurant.findById(idOf(parent.restaurant)).populate('zone');
      return restaurant?.zone ?? null;
    },
    selectedPrepTime: (parent: any) => parent.preparationTime ?? null,
  },
};
