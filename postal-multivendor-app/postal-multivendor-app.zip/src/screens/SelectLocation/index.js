export { default } from './SelectLocation'
