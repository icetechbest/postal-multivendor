'use client';

// Core
import React, { useCallback, useEffect, useState } from 'react';

// Interfaces§
import {
  IConfiguration,
  IConfigurationProviderProps,
  ILazyQueryResult,
} from '@/lib/utils/interfaces';

// API
import { GET_CONFIGURATION } from '@/lib/api/graphql';

// Hooks
import { useLazyQueryQL } from '@/lib/hooks/useLazyQueryQL';

export const ConfigurationContext = React.createContext<
  IConfiguration | undefined
>({
  _id: '',
  pushToken: '',
  webClientID: '',
  mapTileUrl: '',
  geocodingUrl: '',
  routingUrl: '',
  webAmplitudeApiKey: '',
  appAmplitudeApiKey: '',
  webSentryUrl: '',
  apiSentryUrl: '',
  customerAppSentryUrl: '',
  restaurantAppSentryUrl: '',
  riderAppSentryUrl: '',
  skipEmailVerification: false,
  skipMobileVerification: false,
  skipWhatsAppOTP: false,
  currency: '',
  currencySymbol: '',
  deliveryRate: 0,
  twilioEnabled: false,
  twilioAccountSid: '',
  twilioAuthToken: '',
  twilioPhoneNumber: '',
  twilioWhatsAppNumber: '',
  firebaseKey: '',
  appId: '',
  authDomain: '',
  storageBucket: '',
  msgSenderId: '',
  measurementId: '',
  projectId: '',
  dashboardSentryUrl: '',
  cloudinaryUploadUrl: '',
  cloudinaryApiKey: '',
  vapidKey: '',
  isPaidVersion: false,
  email: '',
  emailName: '',
  password: '',
  enableEmail: false,
  formEmail: '',
  sendGridApiKey: '',
  sendGridEnabled: false,
  sendGridEmail: '',
  sendGridEmailName: '',
  sendGridPassword: '',
  androidClientID: '',
  iOSClientID: '',
  expoClientID: '',
  termsAndConditions: '',
  privacyPolicy: '',
  testOtp: '',
  costType: '',
  enableRiderDemo: false,
  enableRestaurantDemo: false,
  enableAdminDemo: false,
});

export const ConfigurationProvider: React.FC<IConfigurationProviderProps> = ({
  children,
}) => {
  const [configuration, setConfiguration] = useState<
    IConfiguration | undefined
  >();
  // API

  const { fetch, loading, error, data } = useLazyQueryQL(GET_CONFIGURATION, {
    debounceMs: 300,
  }) as ILazyQueryResult<
    { configuration: IConfiguration } | undefined,
    undefined
  >;

  // Handlers
  const onFetchConfiguration = () => {
    const configuration: IConfiguration | undefined =
      loading || error || !data
        ? {
            _id: '',
            pushToken: '',
            webClientID: '',
            mapTileUrl: '',
            geocodingUrl: '',
            routingUrl: '',
            webAmplitudeApiKey: '',
            appAmplitudeApiKey: '',
            webSentryUrl: '',
            apiSentryUrl: '',
            customerAppSentryUrl: '',
            restaurantAppSentryUrl: '',
            riderAppSentryUrl: '',
            skipEmailVerification: false,
            skipMobileVerification: false,
            currency: '',
            currencySymbol: '',
            deliveryRate: 0,
                      twilioEnabled: false,
            twilioAccountSid: '',
            twilioAuthToken: '',
            twilioPhoneNumber: '',
            firebaseKey: '',
            appId: '',
            authDomain: '',
            storageBucket: '',
            msgSenderId: '',
            measurementId: '',
            projectId: '',
            dashboardSentryUrl: '',
            cloudinaryUploadUrl: '',
            cloudinaryApiKey: '',
            vapidKey: '',
            isPaidVersion: false,
            email: '',
            emailName: '',
            password: '',
            enableEmail: false,
            formEmail: '',
            sendGridApiKey: '',
            sendGridEnabled: false,
            sendGridEmail: '',
            sendGridEmailName: '',
            sendGridPassword: '',
            androidClientID: '',
            iOSClientID: '',
            expoClientID: '',
            termsAndConditions: '',
            privacyPolicy: '',
            testOtp: '',
            costType: '',
            enableRiderDemo: false,
            enableRestaurantDemo: false,
            enableAdminDemo: false,
          }
        : data?.configuration;

    setConfiguration(configuration);
  };

  const fetchConfiguration = useCallback(() => {
    fetch();
  }, [fetch]);

  // Use Effect
  useEffect(() => {
    fetchConfiguration();
  }, []);

  useEffect(() => {
    onFetchConfiguration();
  }, [data]);

  return (
    <ConfigurationContext.Provider value={configuration}>
      {children}
    </ConfigurationContext.Provider>
  );
};
